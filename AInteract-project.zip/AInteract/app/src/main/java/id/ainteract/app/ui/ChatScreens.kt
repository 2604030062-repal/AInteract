package id.ainteract.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.ainteract.app.AppViewModel
import id.ainteract.app.R
import id.ainteract.app.data.ChatMessage
import id.ainteract.app.data.Conversation
import id.ainteract.app.data.LocalSocialBackend
import id.ainteract.app.data.User
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** The Chat tab: social chat between people who have an AInteract account. */
@Composable
fun ChatTab(vm: AppViewModel, peer: String?, onOpenPeer: (String?) -> Unit, onGoProfile: () -> Unit) {
    val me = vm.user
    when {
        me == null -> SignedOutPrompt(onGoProfile)
        peer != null -> ChatRoom(vm, me, peer, onBack = { onOpenPeer(null) })
        else -> ConversationList(vm, me, onOpenPeer)
    }
}

@Composable
private fun SignedOutPrompt(onGoProfile: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Color.White)) {
        ScreenHeader("Chats")
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(painterResource(R.drawable.logo), contentDescription = null, modifier = Modifier.size(120.dp))
            Spacer(Modifier.height(16.dp))
            Text(
                "Chat with other AInteract users",
                fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Sign in or create an AInteract account to message people and talk about the books you read.",
                fontSize = 15.sp, color = AColors.Muted, textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))
            GradientButton("Sign in or create account", onGoProfile)
        }
    }
}

// ------------------------------------------------------------------ conversation list

@Composable
private fun ConversationList(vm: AppViewModel, me: User, onOpenPeer: (String?) -> Unit) {
    var conversations by remember { mutableStateOf<List<Conversation>>(emptyList()) }
    var people by remember { mutableStateOf<List<User>>(emptyList()) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(me.username) {
        while (true) {
            conversations = vm.social.conversations(me.username)
            delay(2000)
        }
    }
    LaunchedEffect(query, me.username) {
        people = vm.social.searchUsers(query, me.username)
    }

    Column(Modifier.fillMaxSize().background(Color.White)) {
        ScreenHeader("Chats")
        Box(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            InputField(query, { query = it }, "Search people on AInteract")
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(bottom = 16.dp)) {
            if (query.isBlank() && conversations.isNotEmpty()) {
                item(key = "h-conv") { SectionLabel("Conversations") }
                items(conversations, key = { "c-" + it.peer.username }) { conv ->
                    ConversationRow(conv) { onOpenPeer(conv.peer.username) }
                }
            }
            item(key = "h-people") { SectionLabel(if (query.isBlank()) "People on AInteract" else "Results") }
            if (people.isEmpty()) {
                item(key = "empty") {
                    Text(
                        "No one found.",
                        color = AColors.Muted, fontSize = 15.sp,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                    )
                }
            }
            items(people, key = { "p-" + it.username }) { user ->
                PersonRow(user) { onOpenPeer(user.username) }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold,
        color = AColors.Blue,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 4.dp),
    )
}

@Composable
private fun ConversationRow(conv: Conversation, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickableNoRipple(onClick).padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(conv.peer.displayName, 52)
        Spacer(Modifier.size(14.dp))
        Column(Modifier.weight(1f)) {
            NameLine(conv.peer)
            Text(
                conv.last?.body ?: "",
                fontSize = 14.sp,
                color = AColors.Muted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            conv.last?.let { Text(formatTime(it.ts), fontSize = 12.sp, color = AColors.Muted) }
            if (conv.unread > 0) {
                Spacer(Modifier.height(4.dp))
                Box(
                    Modifier.clip(CircleShape).background(GradientBrush).size(22.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(conv.unread.coerceAtMost(99).toString(), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun PersonRow(user: User, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickableNoRipple(onClick).padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(user.displayName, 44)
        Spacer(Modifier.size(14.dp))
        Column(Modifier.weight(1f)) {
            NameLine(user)
            Text("@${user.username}", fontSize = 13.sp, color = AColors.Muted)
        }
    }
}

@Composable
private fun NameLine(user: User) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(user.displayName, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (user.username == LocalSocialBackend.OFFICIAL) {
            Spacer(Modifier.size(8.dp))
            Text(
                "OFFICIAL DEMO",
                fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White,
                modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(AColors.Blue).padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
    }
}

// ------------------------------------------------------------------ chat room

@Composable
private fun ChatRoom(vm: AppViewModel, me: User, peerUsername: String, onBack: () -> Unit) {
    var peer by remember { mutableStateOf<User?>(null) }
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    BackHandler(onBack = onBack)

    LaunchedEffect(peerUsername) { peer = vm.social.getUser(peerUsername) }
    LaunchedEffect(peerUsername, me.username) {
        while (true) {
            messages = vm.social.messages(me.username, peerUsername)
            vm.social.markRead(me.username, peerUsername)
            delay(1500)
        }
    }
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    fun send() {
        val text = input.trim()
        if (text.isEmpty()) return
        input = ""
        scope.launch {
            vm.social.send(me.username, peerUsername, text)
            messages = vm.social.messages(me.username, peerUsername)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.White)
            .windowInsetsPadding(WindowInsets.ime.union(WindowInsets.navigationBars))
    ) {
        // top bar
        Column(Modifier.fillMaxWidth().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                val shown = peer
                Avatar(shown?.displayName ?: peerUsername, 40)
                Spacer(Modifier.size(12.dp))
                Column {
                    Text(shown?.displayName ?: peerUsername, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("@$peerUsername", fontSize = 12.sp, color = AColors.Muted)
                }
            }
            HorizontalDivider(color = Color.Black, thickness = 1.dp)
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(messages, key = { it.id }) { m -> MessageBubble(m, mine = m.from == me.username) }
        }

        BasicTextField(
            value = input,
            onValueChange = { input = it },
            textStyle = TextStyle(color = Color.Black, fontSize = 16.sp),
            cursorBrush = SolidColor(AColors.Blue),
            maxLines = 4,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { send() }),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            decorationBox = { inner ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, AColors.Blue, RoundedCornerShape(28.dp))
                        .padding(start = 18.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.weight(1f).padding(vertical = 6.dp)) {
                        if (input.isEmpty()) Text("Message", color = Color.Gray, fontSize = 16.sp)
                        inner()
                    }
                    Box(
                        Modifier.size(42.dp).clip(CircleShape).background(HorizontalGradientBrush).clickableNoRipple { send() },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(22.dp))
                    }
                }
            },
        )
    }
}

@Composable
private fun MessageBubble(m: ChatMessage, mine: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        val shape = RoundedCornerShape(
            topStart = 18.dp, topEnd = 18.dp,
            bottomStart = if (mine) 18.dp else 4.dp,
            bottomEnd = if (mine) 4.dp else 18.dp,
        )
        Column(
            Modifier
                .widthIn(max = 290.dp)
                .clip(shape)
                .background(if (mine) HorizontalGradientBrush else SolidColor(Color(0xFFEFEFF4)))
                .padding(horizontal = 14.dp, vertical = 8.dp),
        ) {
            Text(m.body, color = if (mine) Color.White else Color.Black, fontSize = 16.sp, lineHeight = 21.sp)
            Text(
                formatTime(m.ts),
                color = if (mine) Color(0xCCFFFFFF) else AColors.Muted,
                fontSize = 10.sp,
                modifier = Modifier.align(Alignment.End),
            )
        }
    }
}

private fun formatTime(ts: Long): String {
    val now = System.currentTimeMillis()
    val sameDay = now / 86_400_000L == ts / 86_400_000L
    val fmt = SimpleDateFormat(if (sameDay) "HH:mm" else "dd/MM HH:mm", Locale.getDefault())
    return fmt.format(Date(ts))
}
