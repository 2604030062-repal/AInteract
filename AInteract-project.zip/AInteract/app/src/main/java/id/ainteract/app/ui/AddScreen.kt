package id.ainteract.app.ui

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.ainteract.app.data.Genre
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val MAX_IMPORT_CHARS = 2_000_000
private const val MIN_CONTENT_CHARS = 150

/** The "Add" button in the middle of the bottom bar: put your own text into the library. */
@Composable
fun AddScreen(
    onAdd: (title: String, author: String, genre: Genre, description: String, content: String) -> Unit,
    onDone: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by rememberSaveable { mutableStateOf("") }
    var author by rememberSaveable { mutableStateOf("") }
    var genreName by rememberSaveable { mutableStateOf(Genre.NONFICTION.name) }
    var description by rememberSaveable { mutableStateOf("") }
    var content by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { r ->
                        val sb = StringBuilder()
                        val buf = CharArray(8192)
                        while (sb.length < MAX_IMPORT_CHARS) {
                            val n = r.read(buf)
                            if (n < 0) break
                            sb.append(buf, 0, n)
                        }
                        sb.toString()
                    }
                    val name = context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                        val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
                    }
                    text to name
                } catch (e: Exception) {
                    null to null
                }
            }
            val (text, name) = result
            if (text.isNullOrBlank()) {
                error = "Could not read that file. Please choose a plain text (.txt) file."
            } else {
                content = text
                error = null
                if (title.isBlank() && name != null) title = name.substringBeforeLast('.')
            }
        }
    }

    Column(Modifier.fillMaxSize().background(Color.White)) {
        ScreenHeader("Add a book")
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "Add your own text. AInteract can then summarize it, quiz you on it, turn it into an infographic and answer questions about it, all offline.",
                fontSize = 14.sp, color = AColors.Muted, lineHeight = 19.sp,
            )

            InputField(title, { title = it }, "Title")
            InputField(author, { author = it }, "Author (optional)")

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Genre.values().forEach { g ->
                    val selected = g.name == genreName
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (selected) HorizontalGradientBrush else androidx.compose.ui.graphics.SolidColor(Color.White))
                            .border(1.5.dp, AColors.Blue, RoundedCornerShape(50))
                            .clickableNoRipple { genreName = g.name }
                            .padding(horizontal = 20.dp, vertical = 9.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(g.label, color = if (selected) Color.White else AColors.Blue, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }

            InputField(description, { description = it }, "Short description (optional)", singleLine = false, minLines = 2)
            InputField(content, { content = it }, "Paste the text here", singleLine = false, minLines = 8)

            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.5.dp, AColors.Blue, RoundedCornerShape(16.dp))
                    .clickableNoRipple { picker.launch("text/*") }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("Import a .txt file", color = AColors.Blue, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            error?.let { Text(it, color = Color(0xFFC62828), fontSize = 14.sp) }

            GradientButton("Add to library", onClick = {
                when {
                    title.isBlank() -> error = "Please enter a title."
                    content.trim().length < MIN_CONTENT_CHARS ->
                        error = "Add at least a few sentences ($MIN_CONTENT_CHARS+ characters) so AInteract has something to work with."
                    else -> {
                        onAdd(title, author, Genre.valueOf(genreName), description, content)
                        toast(context, "Book added to your library")
                        title = ""; author = ""; description = ""; content = ""; error = null
                        onDone()
                    }
                }
            })
            Spacer(Modifier.height(24.dp))
        }
    }
}
