package id.ainteract.app.ai

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import kotlin.math.ceil
import kotlin.math.max

/** Draws the "Make Infografis" picture offline with plain Android Canvas. */
object InfographicRenderer {

    private const val W = 1080
    private const val MARGIN = 64
    private val PURPLE = Color.parseColor("#7F03FE")
    private val BLUE = Color.parseColor("#092FFF")
    private val DEEP = Color.parseColor("#0649C7")
    private val SOFT = Color.parseColor("#EAF0FF")
    private val INK = Color.parseColor("#14213D")

    fun render(title: String, author: String, text: String): Bitmap {
        val keywords = OfflineAI.keywords(text, 5)
        val points = OfflineAI.summarize(text, 4).map { clip(it, 190) }
        val words = OfflineAI.wordCount(text)
        val minutes = max(1, ceil(words / 200.0).toInt())
        val sentenceCount = OfflineAI.sentences(text).size

        val bmp = Bitmap.createBitmap(W, 3200, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)

        var y = 0f

        // ---- header band
        val headerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 62f; typeface = Typeface.DEFAULT_BOLD
        }
        val titleLayout = layout(clip(title, 110), headerPaint, W - 2 * MARGIN)
        val authorPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#D7E0FF"); textSize = 34f }
        val authorLayout = if (author.isNotBlank()) layout(author, authorPaint, W - 2 * MARGIN) else null
        val headerH = 120f + titleLayout.height + (authorLayout?.height ?: 0) + 60f
        val band = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, 0f, headerH, PURPLE, BLUE, Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, W.toFloat(), headerH, band)
        val tagPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D7E0FF"); textSize = 30f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.15f
        }
        c.drawText("AINTERACT  •  INFOGRAFIS", MARGIN.toFloat(), 80f, tagPaint)
        draw(c, titleLayout, MARGIN.toFloat(), 110f)
        if (authorLayout != null) draw(c, authorLayout, MARGIN.toFloat(), 110f + titleLayout.height + 14f)
        y = headerH + 70f

        // ---- stats row
        val stats = listOf(words.toString() to "words", "$minutes min" to "read time", sentenceCount.toString() to "sentences")
        val boxW = (W - 2 * MARGIN - 2 * 30) / 3f
        val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = SOFT }
        val bigPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = DEEP; textSize = 52f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
        }
        val smallPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = INK; textSize = 30f; textAlign = Paint.Align.CENTER
        }
        stats.forEachIndexed { i, (big, small) ->
            val left = MARGIN + i * (boxW + 30f)
            c.drawRoundRect(RectF(left, y, left + boxW, y + 160f), 28f, 28f, boxPaint)
            c.drawText(big, left + boxW / 2, y + 80f, bigPaint)
            c.drawText(small, left + boxW / 2, y + 125f, smallPaint)
        }
        y += 160f + 80f

        // ---- key themes (connected circles, like the icon in the design)
        y = sectionTitle(c, "Key themes", y)
        if (keywords.isNotEmpty()) {
            val n = keywords.size
            val slot = (W - 2 * MARGIN) / n.toFloat()
            val cy = y + 90f
            val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = BLUE; strokeWidth = 8f; style = Paint.Style.STROKE }
            if (n > 1) c.drawLine(MARGIN + slot / 2, cy, MARGIN + slot * (n - 0.5f), cy, line)
            val fill = Paint(Paint.ANTI_ALIAS_FLAG)
            val label = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = INK; textSize = 28f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
            }
            keywords.forEachIndexed { i, k ->
                val cx = MARGIN + slot * (i + 0.5f)
                fill.shader = LinearGradient(cx, cy - 56f, cx, cy + 56f, PURPLE, BLUE, Shader.TileMode.CLAMP)
                c.drawCircle(cx, cy, 56f, fill)
                val num = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE; textSize = 44f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
                }
                c.drawText((i + 1).toString(), cx, cy + 16f, num)
                label.textSize = if (k.length > 9) 22f else 28f
                c.drawText(clip(k, 12), cx, cy + 56f + 52f, label)
            }
            y = cy + 56f + 52f + 80f
        }

        // ---- key points
        y = sectionTitle(c, "Key points", y)
        val pointPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = INK; textSize = 34f }
        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = SOFT }
        val badge = Paint(Paint.ANTI_ALIAS_FLAG)
        val badgeText = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 36f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
        }
        points.forEachIndexed { i, p ->
            val textLeft = MARGIN + 130f
            val pl = layout(p, pointPaint, (W - MARGIN - textLeft).toInt())
            val cardH = pl.height + 60f
            c.drawRoundRect(RectF(MARGIN.toFloat(), y, (W - MARGIN).toFloat(), y + cardH), 32f, 32f, cardPaint)
            val bx = MARGIN + 66f
            val by = y + cardH / 2
            badge.shader = LinearGradient(bx, by - 36f, bx, by + 36f, PURPLE, BLUE, Shader.TileMode.CLAMP)
            c.drawCircle(bx, by, 36f, badge)
            c.drawText((i + 1).toString(), bx, by + 13f, badgeText)
            draw(c, pl, textLeft, y + 30f)
            y += cardH + 28f
        }

        // ---- footer
        y += 30f
        val footer = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#7A869A"); textSize = 28f; textAlign = Paint.Align.CENTER
        }
        c.drawText("Generated offline by AInteract", W / 2f, y + 30f, footer)
        y += 90f

        return Bitmap.createBitmap(bmp, 0, 0, W, y.toInt().coerceAtMost(bmp.height))
    }

    private fun sectionTitle(c: Canvas, title: String, y: Float): Float {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = DEEP; textSize = 46f; typeface = Typeface.DEFAULT_BOLD }
        c.drawText(title, MARGIN.toFloat(), y + 46f, p)
        val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(MARGIN.toFloat(), 0f, MARGIN + 180f, 0f, PURPLE, BLUE, Shader.TileMode.CLAMP)
        }
        c.drawRoundRect(RectF(MARGIN.toFloat(), y + 66f, MARGIN + 180f, y + 76f), 5f, 5f, bar)
        return y + 110f
    }

    private fun layout(text: String, paint: TextPaint, width: Int): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, 1.15f)
            .build()

    private fun draw(c: Canvas, l: StaticLayout, x: Float, y: Float) {
        c.save()
        c.translate(x, y)
        l.draw(c)
        c.restore()
    }

    private fun clip(s: String, max: Int): String = if (s.length <= max) s else s.take(max - 1).trimEnd() + "…"
}
