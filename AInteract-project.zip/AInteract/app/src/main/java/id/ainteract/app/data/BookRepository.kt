package id.ainteract.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Built-in books (from the design) plus books the user added, stored as JSON in app storage. */
class BookRepository(private val context: Context) {

    private val file: File get() = File(context.filesDir, "books.json")

    fun all(): List<Book> = SeedBooks.all + userBooks()

    fun userBooks(): List<Book> {
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Book(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    author = o.optString("author", ""),
                    genre = Genre.valueOf(o.getString("genre")),
                    description = o.optString("description", ""),
                    content = o.getString("content"),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(book: Book) = save(userBooks() + book)

    fun remove(id: String) = save(userBooks().filterNot { it.id == id })

    fun clearUserBooks() = save(emptyList())

    private fun save(list: List<Book>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("title", it.title)
                    .put("author", it.author)
                    .put("genre", it.genre.name)
                    .put("description", it.description)
                    .put("content", it.content)
            )
        }
        file.writeText(arr.toString())
    }
}
