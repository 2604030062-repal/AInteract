package id.ainteract.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import id.ainteract.app.AppViewModel
import id.ainteract.app.R

enum class Tab { Home, Chat, Add, Settings, Profile }

private val BAR_HEIGHT = 76.dp
private val BAR_TOTAL = 104.dp

@Composable
fun AppRoot(vm: AppViewModel = viewModel()) {
    var screen by rememberSaveable { mutableStateOf("loading") }
    var tabName by rememberSaveable { mutableStateOf(Tab.Home.name) }
    var readingId by rememberSaveable { mutableStateOf<String?>(null) }
    var chatPeer by rememberSaveable { mutableStateOf<String?>(null) }
    val tab = Tab.valueOf(tabName)

    when (screen) {
        "loading" -> LoadingScreen { screen = "main" }

        "reading" -> {
            val book = vm.book(readingId)
            if (book == null) {
                LaunchedEffect(Unit) { screen = "main" }
            } else {
                ReadingScreen(book, vm.readingFontSize, onBack = { screen = "main" })
            }
        }

        else -> {
            val inChatRoom = tab == Tab.Chat && chatPeer != null
            BackHandler(enabled = tab != Tab.Home && !inChatRoom) { tabName = Tab.Home.name }

            val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
            Box(Modifier.fillMaxSize().background(Color.White)) {
                Box(Modifier.fillMaxSize().padding(bottom = if (inChatRoom) 0.dp else BAR_HEIGHT + navInset)) {
                    when (tab) {
                        Tab.Home -> HomeScreen(
                            userName = vm.user?.displayName,
                            books = vm.books,
                            onRead = { book ->
                                readingId = book.id
                                screen = "reading"
                            },
                            onDelete = { vm.removeBook(it.id) },
                        )

                        Tab.Chat -> ChatTab(
                            vm = vm,
                            peer = chatPeer,
                            onOpenPeer = { chatPeer = it },
                            onGoProfile = { tabName = Tab.Profile.name },
                        )

                        Tab.Add -> AddScreen(
                            onAdd = { title, author, genre, description, content ->
                                vm.addBook(title, author, genre, description, content)
                            },
                            onDone = { tabName = Tab.Home.name },
                        )

                        Tab.Settings -> SettingsScreen(vm)
                        Tab.Profile -> ProfileScreen(vm)
                    }
                }

                if (!inChatRoom) {
                    BottomBar(
                        selected = tab,
                        onSelect = {
                            if (it != Tab.Chat) chatPeer = null
                            tabName = it.name
                        },
                        modifier = Modifier.align(Alignment.BottomCenter),
                    )
                }
            }
        }
    }
}

/**
 * Bottom navigation from the design: Home, Chat, the big AInteract logo ("Add") in the middle,
 * Settings and Profile.
 */
@Composable
private fun BottomBar(selected: Tab, onSelect: (Tab) -> Unit, modifier: Modifier = Modifier) {
    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    Box(modifier.fillMaxWidth().height(BAR_TOTAL + navInset)) {
        // white bar with the thin black line on top
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(BAR_HEIGHT + navInset)
                .background(Color.White)
                .drawBehind {
                    drawLine(Color.Black, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = 1.dp.toPx())
                },
        )
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = navInset)
                .height(BAR_TOTAL),
            verticalAlignment = Alignment.Bottom,
        ) {
            NavIcon(Icons.Outlined.Home, "Home", selected == Tab.Home) { onSelect(Tab.Home) }
            NavIcon(Icons.Outlined.ChatBubbleOutline, "Chat", selected == Tab.Chat) { onSelect(Tab.Chat) }

            Column(
                Modifier.weight(1f).clickableNoRipple { onSelect(Tab.Add) },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Image(painterResource(R.drawable.logo), contentDescription = "Add", modifier = Modifier.size(78.dp))
                Text(
                    "Add",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (selected == Tab.Add) AColors.Blue else Color.Black,
                    modifier = Modifier.padding(bottom = 4.dp),
                )
            }

            NavIcon(Icons.Outlined.Settings, "Settings", selected == Tab.Settings) { onSelect(Tab.Settings) }
            NavIcon(Icons.Outlined.Person, "Profile", selected == Tab.Profile) { onSelect(Tab.Profile) }
        }
    }
}

@Composable
private fun RowScope.NavIcon(icon: ImageVector, description: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.weight(1f).height(BAR_HEIGHT).clickableNoRipple(onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon,
            contentDescription = description,
            tint = if (selected) Color.Black else AColors.Muted,
            modifier = Modifier.size(40.dp),
        )
    }
}
