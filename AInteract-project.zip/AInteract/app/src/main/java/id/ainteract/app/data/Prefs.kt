package id.ainteract.app.data

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("ainteract_prefs", Context.MODE_PRIVATE)

    var sessionUser: String?
        get() = sp.getString("session_user", null)
        set(value) {
            sp.edit().apply {
                if (value == null) remove("session_user") else putString("session_user", value)
            }.apply()
        }

    var readingFontSize: Float
        get() = sp.getFloat("reading_font_size", 16f)
        set(value) {
            sp.edit().putFloat("reading_font_size", value).apply()
        }
}
