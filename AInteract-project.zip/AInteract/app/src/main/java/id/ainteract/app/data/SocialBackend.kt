package id.ainteract.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Everything the social part of AInteract needs from a server.
 *
 * [LocalSocialBackend] stores accounts and messages on this phone, so people who have an
 * AInteract account on the same device can chat. To chat across different phones, implement
 * this interface on top of a real service (Firebase, Supabase, your own API...) and swap it in
 * AppViewModel. Nothing else in the UI needs to change.
 */
interface SocialBackend {
    suspend fun register(username: String, displayName: String, password: String): Result<User>
    suspend fun login(username: String, password: String): Result<User>
    suspend fun getUser(username: String): User?
    suspend fun updateDisplayName(username: String, displayName: String): User?
    suspend fun searchUsers(query: String, exclude: String): List<User>
    suspend fun conversations(me: String): List<Conversation>
    suspend fun messages(me: String, peer: String): List<ChatMessage>
    suspend fun send(me: String, peer: String, body: String)
    suspend fun markRead(me: String, peer: String)
}

class LocalSocialBackend(context: Context) : SocialBackend {

    companion object {
        const val OFFICIAL = "ainteract"
        private const val ITERATIONS = 60_000
        private val USERNAME_RE = Regex("^[a-z0-9_]{3,20}$")
    }

    private val helper = DbHelper(context.applicationContext)
    private val random = SecureRandom()

    private class DbHelper(ctx: Context) : SQLiteOpenHelper(ctx, "ainteract_social.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE users (" +
                    "username TEXT PRIMARY KEY, display_name TEXT NOT NULL, " +
                    "salt TEXT NOT NULL, pass_hash TEXT NOT NULL, created_at INTEGER NOT NULL)"
            )
            db.execSQL(
                "CREATE TABLE messages (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, from_user TEXT NOT NULL, " +
                    "to_user TEXT NOT NULL, body TEXT NOT NULL, ts INTEGER NOT NULL, " +
                    "is_read INTEGER NOT NULL DEFAULT 0)"
            )
            db.execSQL("CREATE INDEX idx_messages_pair ON messages(from_user, to_user)")
            // Official demo account. Empty hash means nobody can sign in as it.
            val cv = ContentValues().apply {
                put("username", OFFICIAL)
                put("display_name", "AInteract Team")
                put("salt", "")
                put("pass_hash", "")
                put("created_at", System.currentTimeMillis())
            }
            db.insert("users", null, cv)
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    }

    private fun hash(password: String, salt: ByteArray): String {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)
        val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return Base64.encodeToString(key, Base64.NO_WRAP)
    }

    override suspend fun register(username: String, displayName: String, password: String): Result<User> =
        withContext(Dispatchers.IO) {
            val uname = username.trim().lowercase()
            val name = displayName.trim().ifEmpty { uname }
            when {
                !USERNAME_RE.matches(uname) ->
                    return@withContext Result.failure(Exception("Username must be 3-20 characters: a-z, 0-9 and _"))
                password.length < 6 ->
                    return@withContext Result.failure(Exception("Password must be at least 6 characters"))
                name.length > 40 ->
                    return@withContext Result.failure(Exception("Display name is too long"))
            }
            val db = helper.writableDatabase
            val exists = db.rawQuery("SELECT 1 FROM users WHERE username = ?", arrayOf(uname)).use { it.moveToFirst() }
            if (exists) return@withContext Result.failure(Exception("That username is already taken"))

            val saltBytes = ByteArray(16).also { random.nextBytes(it) }
            val cv = ContentValues().apply {
                put("username", uname)
                put("display_name", name)
                put("salt", Base64.encodeToString(saltBytes, Base64.NO_WRAP))
                put("pass_hash", hash(password, saltBytes))
                put("created_at", System.currentTimeMillis())
            }
            db.insert("users", null, cv)
            insertMessage(
                OFFICIAL, uname,
                "Welcome to AInteract, $name! Search for other AInteract users in the Chat tab to start a conversation.",
                System.currentTimeMillis(),
            )
            Result.success(User(uname, name))
        }

    override suspend fun login(username: String, password: String): Result<User> = withContext(Dispatchers.IO) {
        val uname = username.trim().lowercase()
        val db = helper.readableDatabase
        db.rawQuery("SELECT display_name, salt, pass_hash FROM users WHERE username = ?", arrayOf(uname)).use { c ->
            if (!c.moveToFirst()) return@withContext Result.failure(Exception("Wrong username or password"))
            val name = c.getString(0)
            val salt = c.getString(1)
            val stored = c.getString(2)
            if (stored.isEmpty() || salt.isEmpty()) return@withContext Result.failure(Exception("Wrong username or password"))
            val computed = hash(password, Base64.decode(salt, Base64.NO_WRAP))
            if (!MessageDigest.isEqual(computed.toByteArray(), stored.toByteArray())) {
                return@withContext Result.failure(Exception("Wrong username or password"))
            }
            Result.success(User(uname, name))
        }
    }

    override suspend fun getUser(username: String): User? = withContext(Dispatchers.IO) {
        helper.readableDatabase
            .rawQuery("SELECT username, display_name FROM users WHERE username = ?", arrayOf(username))
            .use { c -> if (c.moveToFirst()) User(c.getString(0), c.getString(1)) else null }
    }

    override suspend fun updateDisplayName(username: String, displayName: String): User? = withContext(Dispatchers.IO) {
        val name = displayName.trim()
        if (name.isEmpty() || name.length > 40) return@withContext null
        val cv = ContentValues().apply { put("display_name", name) }
        helper.writableDatabase.update("users", cv, "username = ?", arrayOf(username))
        User(username, name)
    }

    override suspend fun searchUsers(query: String, exclude: String): List<User> = withContext(Dispatchers.IO) {
        val q = "%" + query.trim().replace("%", "").replace("_", "") + "%"
        helper.readableDatabase.rawQuery(
            "SELECT username, display_name FROM users " +
                "WHERE username != ? AND (username LIKE ? OR display_name LIKE ?) " +
                "ORDER BY username LIMIT 30",
            arrayOf(exclude, q, q),
        ).use { c ->
            val out = ArrayList<User>()
            while (c.moveToNext()) out.add(User(c.getString(0), c.getString(1)))
            out
        }
    }

    override suspend fun conversations(me: String): List<Conversation> = withContext(Dispatchers.IO) {
        val db = helper.readableDatabase
        val all = ArrayList<ChatMessage>()
        db.rawQuery(
            "SELECT id, from_user, to_user, body, ts FROM messages " +
                "WHERE from_user = ? OR to_user = ? ORDER BY ts DESC, id DESC",
            arrayOf(me, me),
        ).use { c ->
            while (c.moveToNext()) {
                all.add(ChatMessage(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getLong(4)))
            }
        }
        val unread = HashMap<String, Int>()
        db.rawQuery(
            "SELECT from_user, COUNT(*) FROM messages WHERE to_user = ? AND is_read = 0 GROUP BY from_user",
            arrayOf(me),
        ).use { c -> while (c.moveToNext()) unread[c.getString(0)] = c.getInt(1) }

        val lastByPeer = LinkedHashMap<String, ChatMessage>()
        for (m in all) {
            val peer = if (m.from == me) m.to else m.from
            if (peer !in lastByPeer) lastByPeer[peer] = m
        }
        lastByPeer.mapNotNull { (peer, last) ->
            val u = db.rawQuery("SELECT username, display_name FROM users WHERE username = ?", arrayOf(peer))
                .use { c -> if (c.moveToFirst()) User(c.getString(0), c.getString(1)) else null }
            u?.let { Conversation(it, last, unread[peer] ?: 0) }
        }
    }

    override suspend fun messages(me: String, peer: String): List<ChatMessage> = withContext(Dispatchers.IO) {
        helper.readableDatabase.rawQuery(
            "SELECT id, from_user, to_user, body, ts FROM messages " +
                "WHERE (from_user = ? AND to_user = ?) OR (from_user = ? AND to_user = ?) " +
                "ORDER BY ts ASC, id ASC",
            arrayOf(me, peer, peer, me),
        ).use { c ->
            val out = ArrayList<ChatMessage>()
            while (c.moveToNext()) {
                out.add(ChatMessage(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getLong(4)))
            }
            out
        }
    }

    override suspend fun send(me: String, peer: String, body: String) {
        withContext(Dispatchers.IO) {
            val text = body.trim()
            if (text.isEmpty()) return@withContext
            val now = System.currentTimeMillis()
            insertMessage(me, peer, text, now)
            if (peer == OFFICIAL) {
                insertMessage(
                    OFFICIAL, me,
                    "Thanks for your message! This is the official AInteract demo account and it replies automatically. " +
                        "Create a second account on this phone to chat with another AInteract user.",
                    now + 1,
                )
            }
        }
    }

    override suspend fun markRead(me: String, peer: String) {
        withContext(Dispatchers.IO) {
            val cv = ContentValues().apply { put("is_read", 1) }
            helper.writableDatabase.update("messages", cv, "to_user = ? AND from_user = ?", arrayOf(me, peer))
        }
    }

    private fun insertMessage(from: String, to: String, body: String, ts: Long) {
        val cv = ContentValues().apply {
            put("from_user", from)
            put("to_user", to)
            put("body", body)
            put("ts", ts)
            put("is_read", 0)
        }
        helper.writableDatabase.insert("messages", null, cv)
    }
}
