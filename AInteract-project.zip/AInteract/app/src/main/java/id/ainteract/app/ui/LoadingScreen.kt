package id.ainteract.app.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.ainteract.app.R
import kotlinx.coroutines.delay

/** "Loading Screen Apps - 1" */
@Composable
fun LoadingScreen(onDone: () -> Unit) {
    var started by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (started) 1f else 0.8f, tween(900), label = "logoScale")
    val alpha by animateFloatAsState(if (started) 1f else 0f, tween(900), label = "logoAlpha")

    LaunchedEffect(Unit) {
        started = true
        delay(1800)
        onDone()
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Color.White),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(
            painter = painterResource(R.drawable.logo),
            contentDescription = "AInteract",
            modifier = Modifier.size(220.dp).scale(scale).alpha(alpha),
        )
        Text(
            "AInteract",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = AColors.Sheet,
            modifier = Modifier.alpha(alpha),
        )
    }
}
