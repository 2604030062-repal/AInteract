package id.ainteract.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.ainteract.app.AppViewModel
import androidx.compose.foundation.layout.Box

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val context = LocalContext.current
    var confirmClear by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(Color.White)) {
        ScreenHeader("Settings")
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            // reading size
            SettingCard("Reading text size") {
                Slider(
                    value = vm.readingFontSize,
                    onValueChange = { vm.setFontSize(it) },
                    valueRange = 12f..26f,
                    colors = SliderDefaults.colors(
                        thumbColor = AColors.Blue,
                        activeTrackColor = AColors.Blue,
                        inactiveTrackColor = AColors.Soft,
                    ),
                )
                Text(
                    "The quick brown fox jumps over the lazy dog.",
                    fontSize = vm.readingFontSize.sp,
                    lineHeight = (vm.readingFontSize * 1.5f).sp,
                )
            }

            SettingCard("AI mode") {
                Text("Offline version", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = AColors.Blue)
                Text(
                    "Summaries, quizzes, infographics and answers are created on your phone from the text you are reading. No internet connection is needed and your books never leave the device.",
                    fontSize = 14.sp, lineHeight = 20.sp, color = AColors.Muted,
                )
            }

            SettingCard("My library") {
                Text(
                    "Remove every book you added with the Add tab. The built-in books stay.",
                    fontSize = 14.sp, lineHeight = 20.sp, color = AColors.Muted,
                )
                Box(
                    Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.5.dp, Color(0xFFC62828), RoundedCornerShape(12.dp))
                        .clickableNoRipple { confirmClear = true }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("Remove my books", color = Color(0xFFC62828), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }

            SettingCard("About") {
                Text("AInteract 1.0.0", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Read, ask, practise and chat. Built from the \"Prototype of Paper\" design.", fontSize = 14.sp, color = AColors.Muted)
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Remove my books?") },
            text = { Text("This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.clearMyBooks()
                    confirmClear = false
                    toast(context, "Your books were removed")
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun SettingCard(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(AColors.Soft)
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        content()
    }
}
