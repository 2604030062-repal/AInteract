package id.ainteract.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import id.ainteract.app.data.Book
import id.ainteract.app.data.BookRepository
import id.ainteract.app.data.Genre
import id.ainteract.app.data.LocalSocialBackend
import id.ainteract.app.data.Prefs
import id.ainteract.app.data.SocialBackend
import id.ainteract.app.data.User
import kotlinx.coroutines.launch
import java.util.UUID

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = Prefs(app)
    private val bookRepo = BookRepository(app)

    /** Swap this for a remote implementation to chat across different phones. */
    val social: SocialBackend = LocalSocialBackend(app)

    var books by mutableStateOf(bookRepo.all())
        private set

    var user by mutableStateOf<User?>(null)
        private set

    var readingFontSize by mutableStateOf(prefs.readingFontSize)
        private set

    init {
        prefs.sessionUser?.let { name ->
            viewModelScope.launch { user = social.getUser(name) }
        }
    }

    fun book(id: String?): Book? = books.firstOrNull { it.id == id }

    fun addBook(title: String, author: String, genre: Genre, description: String, content: String) {
        val desc = description.trim().ifEmpty {
            val flat = content.trim().replace(Regex("\\s+"), " ")
            if (flat.length > 260) flat.take(260).trimEnd() + "…" else flat
        }
        bookRepo.add(
            Book(
                id = UUID.randomUUID().toString(),
                title = title.trim(),
                author = author.trim(),
                genre = genre,
                description = desc,
                content = content.trim(),
            )
        )
        books = bookRepo.all()
    }

    fun removeBook(id: String) {
        bookRepo.remove(id)
        books = bookRepo.all()
    }

    fun clearMyBooks() {
        bookRepo.clearUserBooks()
        books = bookRepo.all()
    }

    fun setFontSize(size: Float) {
        readingFontSize = size
        prefs.readingFontSize = size
    }

    fun signIn(username: String, password: String, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            val r = social.login(username, password)
            r.onSuccess {
                user = it
                prefs.sessionUser = it.username
            }
            onResult(r.exceptionOrNull()?.message)
        }
    }

    fun register(username: String, displayName: String, password: String, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            val r = social.register(username, displayName, password)
            r.onSuccess {
                user = it
                prefs.sessionUser = it.username
            }
            onResult(r.exceptionOrNull()?.message)
        }
    }

    fun signOut() {
        user = null
        prefs.sessionUser = null
    }

    fun renameUser(displayName: String, onDone: (Boolean) -> Unit) {
        val me = user ?: return
        viewModelScope.launch {
            val updated = social.updateDisplayName(me.username, displayName)
            if (updated != null) user = updated
            onDone(updated != null)
        }
    }
}
