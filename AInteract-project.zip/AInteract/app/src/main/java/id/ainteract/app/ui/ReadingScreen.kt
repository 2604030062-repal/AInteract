package id.ainteract.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.ainteract.app.R
import id.ainteract.app.data.Book

enum class Panel(val title: String) {
    Summary("Make Summary"),
    Quiz("Make Quiz"),
    Infographic("Make Infografis"),
    Ask("AInteract"),
}

/**
 * "Reading Screen - 4", "(if button is pressed) - 5", "(UI AInteract) - 6",
 * "(Create an Summary / quiz / Infographic)".
 */
@Composable
fun ReadingScreen(book: Book, fontSize: Float, onBack: () -> Unit) {
    var menuOpen by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf<Panel?>(null) }
    val ai = remember(book.id) { AiSession(book) }

    BackHandler(enabled = true) {
        when {
            panel != null -> panel = null
            menuOpen -> menuOpen = false
            else -> onBack()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.White)) {
        Column(Modifier.fillMaxSize()) {
            ReadingTopBar(book, onBack)
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Text(
                    text = book.content,
                    fontSize = fontSize.sp,
                    lineHeight = (fontSize * 1.55f).sp,
                    color = Color.Black,
                )
                Spacer(Modifier.height(140.dp))
            }
        }

        // tap anywhere outside the menu to close it
        if (menuOpen) Box(Modifier.fillMaxSize().clickableNoRipple { menuOpen = false })

        if (panel == null) {
            AiMenu(
                open = menuOpen,
                onToggle = { menuOpen = !menuOpen },
                onPick = { picked ->
                    menuOpen = false
                    panel = picked
                },
                modifier = Modifier.align(Alignment.BottomEnd),
            )
        }

        panel?.let { current ->
            PanelHost(current, ai, onClose = { panel = null })
        }
    }
}

@Composable
private fun ReadingTopBar(book: Book, onBack: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color.White).statusBarsPadding()) {
        Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterStart)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.Black)
            }
            Text(
                text = if (book.author.isBlank()) book.title else "${book.title}\n${book.author}",
                fontSize = 15.sp,
                lineHeight = 19.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = Color.Black,
                modifier = Modifier.padding(horizontal = 52.dp),
            )
        }
        HorizontalDivider(color = Color.Black, thickness = 1.dp)
    }
}

// ------------------------------------------------------------------ floating logo + pills

@Composable
private fun AiMenu(
    open: Boolean,
    onToggle: () -> Unit,
    onPick: (Panel) -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(modifier.navigationBarsPadding().padding(end = 14.dp, bottom = 20.dp), contentAlignment = Alignment.BottomEnd) {
        // closed: the round logo button
        AnimatedVisibility(visible = !open, enter = fadeIn(), exit = fadeOut()) {
            Box(
                modifier = Modifier
                    .size(82.dp)
                    .shadow(8.dp, CircleShape)
                    .clip(CircleShape)
                    .background(GradientBrush)
                    .clickableNoRipple(onToggle),
                contentAlignment = Alignment.Center,
            ) {
                Image(painterResource(R.drawable.logo), contentDescription = "AInteract", modifier = Modifier.size(68.dp))
            }
        }
        // open: four pills, "Ask AInteract" being the biggest one
        AnimatedVisibility(
            visible = open,
            enter = fadeIn() + slideInVertically { it / 3 },
            exit = fadeOut() + slideOutVertically { it / 3 },
        ) {
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                MenuPill("Make Summary", R.drawable.ic_book, big = false) { onPick(Panel.Summary) }
                MenuPill("Make Quiz", R.drawable.ic_quiz, big = false) { onPick(Panel.Quiz) }
                MenuPill("Make Infografis", R.drawable.ic_infographic, big = false) { onPick(Panel.Infographic) }
                MenuPill("Ask AInteract", R.drawable.logo, big = true) { onPick(Panel.Ask) }
            }
        }
    }
}

@Composable
private fun MenuPill(label: String, iconRes: Int, big: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier = Modifier
            .width(if (big) 232.dp else 178.dp)
            .height(if (big) 74.dp else 54.dp)
            .shadow(8.dp, shape)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(AColors.Purple, AColors.Blue)))
            .clickableNoRipple(onClick),
        contentAlignment = Alignment.CenterStart,
    ) {
        Text(
            text = label,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = if (big) 22.sp else 15.sp,
            modifier = Modifier.padding(start = if (big) 28.dp else 20.dp),
        )
        Image(
            painter = painterResource(iconRes),
            contentDescription = null,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 6.dp)
                .size(if (big) 58.dp else 42.dp),
        )
    }
}

// ------------------------------------------------------------------ blue bottom panel

@Composable
private fun PanelHost(panel: Panel, ai: AiSession, onClose: () -> Unit) {
    val imeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    Box(Modifier.fillMaxSize().imePadding()) {
        // the white area above the panel closes it
        Box(Modifier.fillMaxSize().clickableNoRipple(onClose))
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .fillMaxHeight(if (imeVisible) 0.96f else 0.68f)
                .clip(RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp))
                .background(AColors.Sheet)
                .clickableNoRipple {}
        ) {
            Text(
                text = panel.title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
            )
            HorizontalDivider(color = AColors.SheetLine, thickness = 1.dp)
            Box(Modifier.weight(1f).fillMaxWidth().then(if (imeVisible) Modifier else Modifier.navigationBarsPadding())) {
                when (panel) {
                    Panel.Summary -> SummaryPanel(ai)
                    Panel.Quiz -> QuizPanel(ai)
                    Panel.Infographic -> InfographicPanel(ai)
                    Panel.Ask -> AskPanel(ai)
                }
            }
        }
    }
}
