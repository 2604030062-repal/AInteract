package id.ainteract.app.ai

import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.random.Random

/**
 * "AI Offline Version" from the design: summaries, quizzes and answers are produced on the
 * device from the book text using classic text-analysis (word frequency, sentence ranking,
 * cloze questions, TF-IDF retrieval). No internet and no downloaded model are needed.
 */
data class QuizQuestion(
    val prompt: String,
    val options: List<String>,
    val answerIndex: Int,
    val explanation: String,
)

object OfflineAI {

    val LETTERS = listOf("A", "B", "C", "D", "E")

    private val STOP_EN = setOf(
        "the", "and", "for", "are", "but", "not", "you", "all", "any", "can", "had", "her", "was", "one", "our",
        "out", "day", "get", "has", "him", "his", "how", "man", "new", "now", "old", "see", "two", "way", "who",
        "boy", "did", "its", "let", "put", "say", "she", "too", "use", "that", "with", "have", "this", "will",
        "your", "from", "they", "know", "want", "been", "good", "much", "some", "time", "very", "when", "come",
        "here", "just", "like", "long", "make", "many", "more", "only", "over", "such", "take", "than", "them",
        "well", "were", "what", "which", "their", "there", "these", "those", "then", "into", "also", "about",
        "after", "again", "against", "because", "before", "being", "between", "both", "could", "does", "doing",
        "during", "each", "every", "few", "further", "most", "other", "should", "same", "still", "through",
        "under", "until", "while", "would", "where", "whom", "why", "shall", "might", "itself", "himself",
        "herself", "themselves", "yourself", "ourselves", "myself", "often", "even", "once", "never", "always",
        "another", "without", "within", "among", "around", "however", "therefore", "although", "whether",
        "something", "someone", "anything", "nothing", "everything", "become", "becomes", "became", "first",
        "second", "third", "part", "tell", "told", "says", "said", "does", "done", "gets", "goes", "gone",
        "made", "makes", "may", "yet", "per", "off", "ago", "own", "least", "less",
    )

    private val STOP_ID = setOf(
        "yang", "dan", "di", "ke", "dari", "ini", "itu", "untuk", "pada", "dengan", "adalah", "atau", "juga",
        "dalam", "akan", "tidak", "sebagai", "oleh", "karena", "agar", "para", "saya", "kami", "kita", "anda",
        "mereka", "dia", "ia", "telah", "sudah", "belum", "bisa", "dapat", "harus", "ada", "lebih", "sangat",
        "apa", "siapa", "bagaimana", "mengapa", "kenapa", "kapan", "dimana", "mana", "berapa", "serta", "namun",
        "tetapi", "sehingga", "bahwa", "jika", "maka", "saat", "setiap", "semua", "banyak", "hanya", "pun",
        "lah", "kah", "nya", "sebuah", "suatu", "tentang", "antara", "secara", "yaitu", "yakni", "ialah",
        "bukan", "lalu", "kemudian", "sebelum", "sesudah", "setelah", "hingga", "sampai", "seperti", "setiap",
    )

    private val STOP: Set<String> = STOP_EN + STOP_ID

    private val INDONESIAN_HINTS = setOf(
        "apa", "siapa", "bagaimana", "mengapa", "kenapa", "kapan", "dimana", "yang", "dan", "adalah", "dari",
        "tentang", "buku", "ringkas", "rangkum", "penulis", "judul", "jelaskan", "ceritakan", "bisa", "tolong",
    )

    private val SENTENCE_END = Regex("(?<=[.!?])\\s+")
    private val ABBREVIATIONS = setOf(
        "st.", "mr.", "mrs.", "ms.", "dr.", "prof.", "vs.", "jr.", "sr.", "no.", "etc.", "e.g.", "i.e.",
        "fig.", "inc.", "ltd.", "co.", "mt.", "dll.", "dsb.", "dst.", "hlm.", "rp.", "yth.",
    )

    /** Everyday words that are poor quiz answers / keywords even though they are frequent. */
    private val GENERIC = setOf(
        "people", "person", "things", "thing", "begins", "begin", "toward", "towards", "former", "cannot",
        "young", "read", "tools", "change", "problem", "problems", "ability", "able", "many", "later", "soon",
        "finally", "really", "simply", "actually", "already", "rather", "lives", "live", "living", "life",
        "world", "make", "makes", "making", "feel", "feels", "give", "gives", "gave", "found", "find", "finds",
        "help", "helps", "keep", "keeps", "turn", "turns", "work", "works", "need", "needs", "seek", "seeks",
        "look", "looks", "going", "goes", "comes", "coming", "meets", "meet", "takes", "taking", "began",
        "confesses", "appears", "offers", "shows", "show", "learn", "learns", "think", "thinks", "believe",
        "yang", "orang", "banyak", "masyarakat", "hal", "cara", "bisa", "dapat",
    )
    private val WORD = Regex("[\\p{L}][\\p{L}'-]*")

    // ---------------------------------------------------------------- text helpers

    fun sentences(text: String): List<String> {
        val pieces = ArrayList<String>()
        for (para in text.split(Regex("\\n+"))) {
            val merged = ArrayList<String>()
            for (part in para.split(SENTENCE_END)) {
                val prev = merged.lastOrNull()
                // do not split after abbreviations such as "St." or "Dr."
                if (prev != null && prev.substringAfterLast(' ').lowercase() in ABBREVIATIONS) {
                    merged[merged.size - 1] = "$prev $part"
                } else {
                    merged.add(part)
                }
            }
            pieces.addAll(merged)
        }
        return pieces
            .map { it.trim().replace(Regex("\\s+"), " ") }
            .filter { it.length >= 25 && it.any(Char::isLetter) }
    }

    private fun contentWords(s: String): List<String> =
        WORD.findAll(s).map { it.value.lowercase() }.filter { it.length > 2 && it !in STOP }.toList()

    private fun frequencies(sents: List<String>): Map<String, Int> {
        val freq = HashMap<String, Int>()
        for (s in sents) for (w in contentWords(s)) freq[w] = (freq[w] ?: 0) + 1
        return freq
    }

    fun wordCount(text: String): Int = WORD.findAll(text).count()

    fun isIndonesian(text: String): Boolean {
        val words = WORD.findAll(text.lowercase()).map { it.value }.toList()
        val hits = words.count { it in INDONESIAN_HINTS }
        return hits >= 1 && hits * 4 >= words.size.coerceAtMost(8)
    }

    // ---------------------------------------------------------------- keywords

    fun keywords(text: String, count: Int = 8): List<String> {
        val sents = sentences(text)
        val freq = frequencies(sents).filterKeys { it.length >= 4 && it !in GENERIC }
        val display = displayForms(sents)
        return freq.entries
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .take(count)
            .map { display[it.key] ?: it.key }
            .map { it.replaceFirstChar { c -> c.uppercase() } }
    }

    /** lowercase word -> form to display (keeps capitalisation of proper nouns). */
    private fun displayForms(sents: List<String>): Map<String, String> {
        val form = HashMap<String, String>()
        for (s in sents) {
            WORD.findAll(s).forEachIndexed { i, m ->
                val w = m.value
                val lw = w.lowercase()
                if (lw.length < 4 || lw in STOP) return@forEachIndexed
                val properNoun = i > 0 && w[0].isUpperCase()
                if (properNoun) form[lw] = w else if (lw !in form) form[lw] = lw
            }
        }
        return form
    }

    // ---------------------------------------------------------------- summary

    fun summarize(text: String, maxSentences: Int = 5): List<String> {
        val sents = sentences(text)
        if (sents.size <= maxSentences) return sents
        val freq = frequencies(sents)
        val maxF = max(1, freq.values.maxOrNull() ?: 1).toDouble()
        val scored = sents.mapIndexed { i, s ->
            val words = contentWords(s)
            val base = words.sumOf { (freq[it] ?: 0) / maxF }
            val norm = base / (words.size.toDouble().pow(0.6) + 1.0)
            val lengthPenalty = if (s.length > 280) 0.7 else 1.0
            val positionBonus = if (i < 3) 1.15 else 1.0
            Triple(i, norm * lengthPenalty * positionBonus, s)
        }
        return scored.sortedByDescending { it.second }
            .take(maxSentences)
            .sortedBy { it.first }
            .map { it.third }
    }

    fun summaryText(title: String, text: String): String {
        val points = summarize(text, 5)
        if (points.isEmpty()) return "This text is too short to summarize."
        val themes = keywords(text, 5).joinToString(", ")
        val sb = StringBuilder()
        sb.append("Summary of \"").append(title.take(80)).append("\"\n\n")
        points.forEach { sb.append("• ").append(it).append("\n\n") }
        if (themes.isNotEmpty()) sb.append("Key themes: ").append(themes)
        return sb.toString().trim()
    }

    // ---------------------------------------------------------------- quiz (options A-E)

    fun makeQuiz(text: String, count: Int = 5, seed: Int = 0): List<QuizQuestion> {
        val sents = sentences(text)
        if (sents.size < 4) return emptyList()
        val freq = frequencies(sents).filterKeys { it.length >= 4 && it !in GENERIC }
        val display = displayForms(sents)
        val pool = freq.entries
            .filter { it.value >= 2 }
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .map { it.key }
            .take(80)
        if (pool.size < 6) return emptyList()
        val rnd = Random(text.hashCode() + seed * 7919)

        // For each candidate sentence choose the most informative keyword to blank out.
        data class Cand(val sentence: String, val answer: String, val score: Int)

        val cands = sents.filter { it.length in 45..230 }.mapNotNull { s ->
            val inSentence = contentWords(s).distinct().filter { it in pool }
            val best = inSentence.maxByOrNull { freq[it] ?: 0 } ?: return@mapNotNull null
            Cand(s, best, freq[best] ?: 0)
        }.shuffled(rnd)

        val usedAnswers = HashSet<String>()
        val picked = ArrayList<Cand>()
        // random tie-breaking keys are computed once so the comparator stays consistent
        val ranked = cands.map { it to (it.score + rnd.nextInt(3)) }.sortedByDescending { it.second }.map { it.first }
        for (c in ranked) {
            if (picked.size >= count) break
            if (c.answer in usedAnswers) continue
            usedAnswers += c.answer
            picked += c
        }
        val order = sents.withIndex().associate { it.value to it.index }

        return picked.sortedBy { order[it.sentence] ?: 0 }.mapNotNull { c ->
            val shown = display[c.answer] ?: c.answer
            val blankRe = Regex("(?i)\\b" + Regex.escape(c.answer) + "\\b")
            if (!blankRe.containsMatchIn(c.sentence)) return@mapNotNull null
            val prompt = blankRe.replaceFirst(c.sentence, "_____")

            val capitalised = shown[0].isUpperCase()
            val distractorPool = pool.filter { it != c.answer }
                .map { it to (kotlin.math.abs(it.length - c.answer.length) + rnd.nextInt(4)) }
                .sortedBy { it.second }
                .map { it.first }
            val sameKind = distractorPool.filter { (display[it] ?: it)[0].isUpperCase() == capitalised }
            val others = distractorPool.filter { it !in sameKind }
            val distractors = (sameKind + others).take(4).map { display[it] ?: it }
            if (distractors.size < 4) return@mapNotNull null

            val options = (distractors + shown).shuffled(rnd)
            QuizQuestion(
                prompt = prompt,
                options = options.map { o -> o.replaceFirstChar { ch -> ch.uppercase() } },
                answerIndex = options.indexOf(shown),
                explanation = c.sentence,
            )
        }
    }

    fun quizAsText(title: String, quiz: List<QuizQuestion>): String {
        val sb = StringBuilder("Quiz: ").append(title.take(80)).append("\n\n")
        quiz.forEachIndexed { i, q ->
            sb.append(i + 1).append(". ").append("Fill in the blank: ").append(q.prompt).append('\n')
            q.options.forEachIndexed { j, o -> sb.append("   ").append(LETTERS[j]).append(". ").append(o).append('\n') }
            sb.append('\n')
        }
        sb.append("Answer key: ")
        sb.append(quiz.mapIndexed { i, q -> "${i + 1}${LETTERS[q.answerIndex]}" }.joinToString(" "))
        return sb.toString()
    }

    // ---------------------------------------------------------------- ask AInteract

    fun answer(question: String, title: String, author: String, text: String): String {
        val id = isIndonesian(question)
        val q = question.lowercase()

        fun has(vararg keys: String) = keys.any { q.contains(it) }

        if (has("summar", "ringkas", "rangkum", "intisari")) {
            return summaryText(title, text)
        }
        if (has("author", "who wrote", "penulis", "pengarang", "siapa yang menulis")) {
            return if (author.isNotBlank()) {
                if (id) "Penulis buku ini adalah $author." else "This book was written by $author."
            } else {
                if (id) "Nama penulis tidak tercantum pada buku ini di aplikasi." else "The author isn't listed for this book in the app."
            }
        }
        if (has("title", "judul")) {
            return if (id) "Judul bacaan ini: \"$title\"." else "The title of this reading is \"$title\"."
        }
        if (has("theme", "tema", "topic", "topik", "keyword", "kata kunci")) {
            val k = keywords(text, 6).joinToString(", ")
            return if (id) "Tema utama yang sering muncul: $k." else "The main themes that come up most often: $k."
        }

        val sents = sentences(text)
        val qWords = contentWords(question).distinct()
        if (qWords.isEmpty() || sents.isEmpty()) {
            return if (id) "Coba tanyakan sesuatu yang lebih spesifik tentang isi buku ini." else "Try asking something more specific about this book."
        }
        val df = HashMap<String, Int>()
        val sentWords = sents.map { contentWords(it).toSet() }
        for (ws in sentWords) for (w in qWords) if (w in ws) df[w] = (df[w] ?: 0) + 1
        val n = sents.size.toDouble()
        val scored = sents.indices.map { i ->
            val s = qWords.sumOf { w -> if (w in sentWords[i]) ln(1.0 + n / (1.0 + (df[w] ?: 0))) else 0.0 }
            i to s
        }.filter { it.second > 0.0 }.sortedByDescending { it.second }.take(2).sortedBy { it.first }

        if (scored.isEmpty()) {
            return if (id) "Saya tidak menemukan jawabannya di dalam teks ini. Coba gunakan kata lain dari buku." else
                "I couldn't find that in this text. Try using words that appear in the book."
        }
        val body = scored.joinToString("\n\n") { sents[it.first] }
        return (if (id) "Berdasarkan teks:\n\n" else "Based on the text:\n\n") + body
    }
}
