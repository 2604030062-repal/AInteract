package id.ainteract.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.ainteract.app.AppViewModel
import id.ainteract.app.data.User

/** Account screen: create or use an AInteract account (needed for the Chat tab). */
@Composable
fun ProfileScreen(vm: AppViewModel) {
    Column(Modifier.fillMaxSize().background(Color.White)) {
        ScreenHeader("Profile")
        val user = vm.user
        if (user == null) SignedOutForm(vm) else SignedInProfile(vm, user)
    }
}

@Composable
private fun ColumnScope.SignedOutForm(vm: AppViewModel) {
    var createMode by rememberSaveable { mutableStateOf(false) }
    var username by rememberSaveable { mutableStateOf("") }
    var displayName by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Column(
        Modifier
            .weight(1f)
            .fillMaxWidth()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text(
            "An AInteract account lets you chat with other readers.",
            fontSize = 15.sp, color = AColors.Muted, lineHeight = 20.sp,
        )

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ModeChip("Sign in", selected = !createMode) { createMode = false; error = null }
            ModeChip("Create account", selected = createMode) { createMode = true; error = null }
        }

        InputField(
            username, { username = it.lowercase().filter { c -> c.isLetterOrDigit() || c == '_' } },
            "Username",
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None),
        )
        if (createMode) InputField(displayName, { displayName = it }, "Display name")
        InputField(
            password, { password = it }, "Password",
            password = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        )

        error?.let { Text(it, color = Color(0xFFC62828), fontSize = 14.sp) }

        GradientButton(
            text = if (busy) "Please wait…" else if (createMode) "Create account" else "Sign in",
            enabled = !busy && username.isNotBlank() && password.isNotBlank(),
            onClick = {
                busy = true
                error = null
                val done: (String?) -> Unit = { message ->
                    busy = false
                    error = message
                }
                if (createMode) vm.register(username, displayName, password, done)
                else vm.signIn(username, password, done)
            },
        )

        if (createMode) {
            Text(
                "Usernames use a-z, 0-9 and _ (3-20 characters). Passwords need at least 6 characters.",
                fontSize = 12.sp, color = AColors.Muted, lineHeight = 17.sp,
            )
        }
    }
}

@Composable
private fun ModeChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) HorizontalGradientBrush else SolidColor(Color.White))
            .border(1.5.dp, AColors.Blue, RoundedCornerShape(50))
            .clickableNoRipple(onClick)
            .padding(horizontal = 20.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (selected) Color.White else AColors.Blue, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
private fun ColumnScope.SignedInProfile(vm: AppViewModel, user: User) {
    val context = LocalContext.current
    var name by rememberSaveable(user.username) { mutableStateOf(user.displayName) }

    Column(
        Modifier
            .weight(1f)
            .fillMaxWidth()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Avatar(user.displayName, 96)
        Text(user.displayName, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text("@${user.username}", fontSize = 15.sp, color = AColors.Muted)
        Spacer(Modifier.height(10.dp))

        InputField(name, { name = it }, "Display name")
        GradientButton("Save display name", onClick = {
            vm.renameUser(name) { ok -> toast(context, if (ok) "Display name updated" else "Please enter a valid name") }
        }, enabled = name.isNotBlank() && name.trim() != user.displayName)

        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.5.dp, Color(0xFFC62828), RoundedCornerShape(16.dp))
                .clickableNoRipple { vm.signOut() }
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text("Sign out", color = Color(0xFFC62828), fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}
