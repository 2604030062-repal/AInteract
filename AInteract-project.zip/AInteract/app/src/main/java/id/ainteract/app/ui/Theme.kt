package id.ainteract.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Colors sampled from the Figma exports. */
object AColors {
    val Purple = Color(0xFF7F03FE)
    val Blue = Color(0xFF092FFF)
    val Sheet = Color(0xFF0649C7)
    val SheetLine = Color(0xFF82A4E3)
    val ReadNow = Color(0xFF0003A8)
    val Ink = Color(0xFF000000)
    val Muted = Color(0xFF6B6B6B)
    val Soft = Color(0xFFEAF0FF)
}

val GradientBrush: Brush = Brush.verticalGradient(listOf(AColors.Purple, AColors.Blue))
val HorizontalGradientBrush: Brush = Brush.horizontalGradient(listOf(AColors.Purple, AColors.Blue))

@Composable
fun AInteractTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = AColors.Blue,
            onPrimary = Color.White,
            background = Color.White,
            surface = Color.White,
            onSurface = Color.Black,
        ),
        content = content,
    )
}
