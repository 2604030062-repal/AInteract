package id.ainteract.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Book
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.ainteract.app.data.Book
import id.ainteract.app.data.Genre

/** "Main Screen UI -2" and "Main Screen UI (if scrolled) - 3": the Home tab. */
@Composable
fun HomeScreen(
    userName: String?,
    books: List<Book>,
    onRead: (Book) -> Unit,
    onDelete: (Book) -> Unit,
) {
    val fiction = books.filter { it.genre == Genre.FICTION }
    val nonfiction = books.filter { it.genre == Genre.NONFICTION }
    var toDelete by remember { mutableStateOf<Book?>(null) }

    Column(Modifier.fillMaxSize().background(Color.White)) {
        // The header stays fixed while the shelves scroll underneath it.
        ScreenHeader("Welcome,\n${userName ?: "User"}!")

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(bottom = 24.dp),
        ) {
            if (fiction.isNotEmpty()) {
                item(key = "h-fiction") { ShelfTitle("Fiction Books") }
                items(fiction, key = { it.id }) { BookCard(it, onRead) { b -> toDelete = b } }
            }
            if (nonfiction.isNotEmpty()) {
                item(key = "h-nonfiction") { ShelfTitle("Nonfiction Books") }
                items(nonfiction, key = { it.id }) { BookCard(it, onRead) { b -> toDelete = b } }
            }
        }
    }

    toDelete?.let { book ->
        if (book.builtIn) {
            toDelete = null
        } else {
            AlertDialog(
                onDismissRequest = { toDelete = null },
                title = { Text("Remove book?") },
                text = { Text("\"${book.title}\" will be removed from your library.") },
                confirmButton = {
                    TextButton(onClick = { onDelete(book); toDelete = null }) { Text("Remove") }
                },
                dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } },
            )
        }
    }
}

@Composable
private fun ShelfTitle(text: String) {
    Row(
        modifier = Modifier.padding(start = 12.dp, end = 12.dp, top = 14.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        Text(" »", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = AColors.Blue)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BookCard(book: Book, onRead: (Book) -> Unit, onLongPress: (Book) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = {}, onLongClick = { if (!book.builtIn) onLongPress(book) })
            .padding(horizontal = 6.dp, vertical = 8.dp),
    ) {
        Cover(book, Modifier.width(148.dp).height(214.dp).clip(RoundedCornerShape(24.dp)))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = book.title,
                fontSize = 17.sp,
                lineHeight = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                maxLines = 4,
                overflow = TextOverflow.Ellipsis,
            )
            if (book.author.isNotBlank()) {
                Text(
                    text = book.author,
                    fontSize = 16.sp,
                    lineHeight = 19.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = underlinedText(book.description, book.underlined),
                fontSize = 12.sp,
                lineHeight = 15.sp,
                color = Color.Black,
                maxLines = 9,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(8.dp))
            ReadNowButton(onClick = { onRead(book) })
        }
    }
}

@Composable
private fun ReadNowButton(onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = AColors.ReadNow, contentColor = Color.White),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
        modifier = Modifier.shadow(6.dp, RoundedCornerShape(12.dp)),
    ) {
        Icon(Icons.Outlined.Book, contentDescription = null, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(8.dp))
        Text("Read Now", fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/** Book cover from the design, or a generated gradient cover for books the user adds. */
@Composable
fun Cover(book: Book, modifier: Modifier) {
    val res = book.coverRes
    if (res != null) {
        Image(
            painter = painterResource(res),
            contentDescription = book.title,
            contentScale = ContentScale.Crop,
            modifier = modifier,
        )
    } else {
        Box(modifier.background(GradientBrush), contentAlignment = Alignment.Center) {
            Text(
                text = book.title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                lineHeight = 24.sp,
                maxLines = 6,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(16.dp),
            )
        }
    }
}

private fun underlinedText(description: String, phrases: List<String>) = buildAnnotatedString {
    append(description)
    for (p in phrases) {
        val i = description.indexOf(p)
        if (i >= 0) addStyle(SpanStyle(textDecoration = TextDecoration.Underline), i, i + p.length)
    }
}
