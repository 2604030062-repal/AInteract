package id.ainteract.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.ainteract.app.ai.InfographicRenderer
import id.ainteract.app.ai.OfflineAI
import id.ainteract.app.ai.QuizQuestion
import id.ainteract.app.data.Book
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ChatBubble(val fromUser: Boolean, val text: String)

/** Results are cached here so reopening a panel does not recompute anything. */
@Stable
class AiSession(val book: Book) {
    var summary by mutableStateOf<String?>(null)
    var quiz by mutableStateOf<List<QuizQuestion>?>(null)
    var quizSeed by mutableIntStateOf(0)
    var infographic by mutableStateOf<Bitmap?>(null)
    val chat = mutableStateListOf(
        ChatBubble(
            fromUser = false,
            text = "Hi! Ask me anything about \"${book.title.take(60)}\". " +
                "I work offline, using only the text of this book.",
        )
    )
}

// ------------------------------------------------------------------ shared pieces

@Composable
private fun PanelFooter(left: @Composable () -> Unit = {}, right: @Composable () -> Unit = {}) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box { left() }
        Box { right() }
    }
}

@Composable
private fun WhiteIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, enabled = true) {
        Icon(icon, contentDescription = description, tint = Color.White, modifier = Modifier.size(30.dp))
    }
}

@Composable
private fun Loading(text: String) {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp, modifier = Modifier.size(32.dp))
        Spacer(Modifier.height(14.dp))
        Text(text, color = Color.White, fontSize = 15.sp)
    }
}

// ------------------------------------------------------------------ Make Summary

@Composable
fun SummaryPanel(ai: AiSession) {
    val context = LocalContext.current
    LaunchedEffect(ai.book.id) {
        if (ai.summary == null) {
            ai.summary = withContext(Dispatchers.Default) { OfflineAI.summaryText(ai.book.title, ai.book.content) }
        }
    }
    val summary = ai.summary
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (summary == null) {
                Loading("Generating summary…")
            } else {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 18.dp)) {
                    Text(summary, color = Color.White, fontSize = 16.sp, lineHeight = 23.sp)
                    Spacer(Modifier.height(16.dp))
                    Text("Generated offline on your device.", color = AColors.SheetLine, fontSize = 12.sp)
                }
            }
        }
        PanelFooter(right = {
            WhiteIconButton(Icons.Outlined.Share, "Share summary") {
                if (summary != null) shareText(context, summary, "Share summary")
            }
        })
    }
}

// ------------------------------------------------------------------ Make Quiz

@Composable
fun QuizPanel(ai: AiSession) {
    val context = LocalContext.current
    LaunchedEffect(ai.book.id, ai.quizSeed) {
        if (ai.quiz == null) {
            ai.quiz = withContext(Dispatchers.Default) { OfflineAI.makeQuiz(ai.book.content, 5, ai.quizSeed) }
        }
    }
    val quiz = ai.quiz
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                quiz == null -> Loading("Creating quiz…")
                quiz.isEmpty() -> Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "This text is too short to make a quiz. Try a longer text.",
                        color = Color.White, fontSize = 17.sp, textAlign = TextAlign.Center,
                    )
                }
                else -> QuizBody(quiz, onNewQuiz = { ai.quiz = null; ai.quizSeed += 1 })
            }
        }
        PanelFooter(right = {
            WhiteIconButton(Icons.Outlined.Share, "Share quiz") {
                if (!quiz.isNullOrEmpty()) shareText(context, OfflineAI.quizAsText(ai.book.title, quiz), "Share quiz")
            }
        })
    }
}

@Composable
private fun QuizBody(quiz: List<QuizQuestion>, onNewQuiz: () -> Unit) {
    var index by remember(quiz) { mutableIntStateOf(0) }
    var selected by remember(quiz) { mutableStateOf<Int?>(null) }
    var score by remember(quiz) { mutableIntStateOf(0) }

    if (index >= quiz.size) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Your score", color = AColors.SheetLine, fontSize = 16.sp)
            Text("$score / ${quiz.size}", color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(20.dp))
            PillButton("Try a new quiz", onNewQuiz)
        }
        return
    }

    val q = quiz[index]
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 14.dp)) {
        Text("Question ${index + 1} of ${quiz.size}", color = AColors.SheetLine, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        Text("Fill in the blank:", color = Color.White, fontSize = 14.sp)
        Text(q.prompt, color = Color.White, fontSize = 18.sp, lineHeight = 25.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(14.dp))

        q.options.forEachIndexed { i, option ->
            val answered = selected != null
            val bg = when {
                !answered -> Color.Transparent
                i == q.answerIndex -> Color(0xFF1B8F4B)
                i == selected -> Color(0xFFC62828)
                else -> Color.Transparent
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(bg)
                    .border(1.5.dp, Color.White.copy(alpha = if (answered && bg == Color.Transparent) 0.35f else 0.9f), RoundedCornerShape(14.dp))
                    .clickableNoRipple {
                        if (selected == null) {
                            selected = i
                            if (i == q.answerIndex) score += 1
                        }
                    }
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(OfflineAI.LETTERS[i], color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.widthIn(min = 26.dp))
                Text(option, color = Color.White, fontSize = 16.sp)
            }
        }

        if (selected != null) {
            Spacer(Modifier.height(10.dp))
            Text(
                if (selected == q.answerIndex) "Correct!" else "Correct answer: ${OfflineAI.LETTERS[q.answerIndex]}",
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp,
            )
            Text("From the text: \"${q.explanation}\"", color = AColors.SheetLine, fontSize = 13.sp, lineHeight = 18.sp)
            Spacer(Modifier.height(12.dp))
            PillButton(if (index == quiz.size - 1) "See score" else "Next question") {
                index += 1
                selected = null
            }
        }
    }
}

@Composable
private fun PillButton(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White)
            .clickableNoRipple(onClick)
            .padding(horizontal = 24.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = AColors.Sheet, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

// ------------------------------------------------------------------ Make Infografis

@Composable
fun InfographicPanel(ai: AiSession) {
    val context = LocalContext.current
    LaunchedEffect(ai.book.id) {
        if (ai.infographic == null) {
            ai.infographic = withContext(Dispatchers.Default) {
                InfographicRenderer.render(ai.book.title, ai.book.author, ai.book.content)
            }
        }
    }
    val bmp = ai.infographic
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (bmp == null) {
                Loading("Designing infographic…")
            } else {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp)) {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "Infographic",
                        contentScale = ContentScale.FillWidth,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)),
                    )
                }
            }
        }
        PanelFooter(
            left = {
                WhiteIconButton(Icons.Outlined.Share, "Share infographic") {
                    if (bmp != null) shareImage(context, bmp)
                }
            },
            right = {
                WhiteIconButton(Icons.Outlined.FileDownload, "Download infographic") {
                    if (bmp != null) toast(context, saveImageToGallery(context, bmp))
                }
            },
        )
    }
}

// ------------------------------------------------------------------ Ask AInteract

@Composable
fun AskPanel(ai: AiSession) {
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }

    LaunchedEffect(ai.chat.size) { listState.animateScrollToItem(ai.chat.lastIndex) }

    fun send() {
        val question = input.trim()
        if (question.isEmpty()) return
        input = ""
        ai.chat.add(ChatBubble(true, question))
        scope.launch {
            val reply = withContext(Dispatchers.Default) {
                OfflineAI.answer(question, ai.book.title, ai.book.author, ai.book.content)
            }
            ai.chat.add(ChatBubble(false, reply))
        }
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            itemsIndexed(ai.chat) { _, bubble ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (bubble.fromUser) Arrangement.End else Arrangement.Start) {
                    Box(
                        Modifier
                            .widthIn(max = 290.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (bubble.fromUser) Color.White else Color.White.copy(alpha = 0.16f))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(
                            bubble.text,
                            color = if (bubble.fromUser) AColors.Sheet else Color.White,
                            fontSize = 15.sp,
                            lineHeight = 21.sp,
                        )
                    }
                }
            }
        }

        // "Type here to ask" pill from the design
        BasicTextField(
            value = input,
            onValueChange = { input = it },
            textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
            cursorBrush = SolidColor(Color.White),
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { send() }),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 14.dp),
            decorationBox = { inner ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color.White, CircleShape)
                        .padding(start = 18.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.weight(1f)) {
                        if (input.isEmpty()) Text("Type here to ask", color = Color.White.copy(alpha = 0.85f), fontSize = 15.sp)
                        inner()
                    }
                    IconButton(onClick = { send() }) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            },
        )
    }
}
