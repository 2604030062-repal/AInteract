package id.ainteract.app.data

import id.ainteract.app.R

/**
 * The three books shown on the Main Screen in the Figma design.
 * Card descriptions are the texts from the design. The reading text is an original
 * overview written for this prototype; replace it with full texts whenever you like
 * (or add your own books with the "Add" tab).
 */
object SeedBooks {

    private val crimeText = """
Part One. On a stifling July evening in St. Petersburg, Rodion Raskolnikov, a former law student, leaves the tiny rented room where he has been hiding from his debts and from everyone who knows him. He is poor, proud and feverish with isolation. Over the past months he has built a theory in his mind: that a few extraordinary people have the right to step over ordinary moral law if their goals serve humanity, and that the world would lose nothing if a greedy, useless person were removed.

His target is Alyona Ivanovna, an elderly pawnbroker who lends money at cruel rates and treats her half-sister Lizaveta like a servant. Raskolnikov visits her flat to rehearse the plan, and then, after a series of coincidences that feel like fate, he returns with an axe. He kills Alyona. Lizaveta walks in unexpectedly, and he kills her too. He escapes with a few small items and hides them under a stone without ever counting their value.

Part Two. Raskolnikov collapses into fever and delirium. When he recovers he finds that guilt, fear and arrogance tear at him at the same time. He meets Marmeladov, a drunken former official, in a tavern. Marmeladov confesses that his daughter Sonya has been forced into prostitution to feed her stepmother and young siblings. Soon afterwards Marmeladov is run over by a carriage and dies, and Raskolnikov gives the family his last money.

A letter arrives from his mother Pulcheria. His sister Dunya is engaged to Luzhin, a vain and calculating lawyer who wants a grateful and obedient wife. Dunya had also been harassed by her former employer, Svidrigailov. Raskolnikov decides that he will not allow the marriage, and his loyal friend Razumikhin helps look after him and his family.

Part Three and Four. Porfiry Petrovich, the investigating magistrate, begins a patient psychological duel with Raskolnikov. He never accuses him directly. He talks about crime, conscience and an article Raskolnikov once wrote about extraordinary men, and he waits for the young man to give himself away. Meanwhile Luzhin is exposed as a schemer who tries to accuse Sonya of theft, and Dunya breaks the engagement.

Raskolnikov seeks out Sonya. She is gentle, deeply religious and strong in a way he is not. At his request she reads the story of the raising of Lazarus. He begins to see that his theory has not made him a Napoleon but only a man who has killed two people and cut himself off from every human tie.

Part Five and Six. Svidrigailov appears in the city, overhears Raskolnikov confessing to Sonya, and uses the secret for his own purposes. He offers help to the Marmeladov children, and then, haunted by his own past, takes his own life. Porfiry urges Raskolnikov to confess voluntarily because it will lessen his sentence and save his soul.

Epilogue. Raskolnikov finally confesses to the police and is sentenced to eight years of hard labour in Siberia, a light sentence because of his confession and his earlier kindness. Sonya follows him and lives near the prison. At first he is cold and bitter, but during a long illness he begins to feel love for her and to understand that suffering can lead to a new life. The novel ends with the promise of his slow spiritual resurrection.

Themes. Crime and Punishment asks whether a person can place himself above morality, how guilt works inside the mind, and whether compassion and faith can restore someone who has done terrible things. Dostoevsky shows poverty, pride and isolation as forces that push people toward desperate choices, and he shows love and suffering as the road back toward other people.
""".trimIndent()

    private val filosofiText = """
Stoicism is an ancient school of philosophy that began in Athens around 300 BC and later flourished in Rome through thinkers such as Seneca, Epictetus and the emperor Marcus Aurelius. Its central idea is simple: we cannot control events, but we can control how we judge them and how we act. Many modern readers turn to Stoicism because it offers practical tools for anxiety, anger and stress.

The dichotomy of control. Epictetus taught that some things are up to us and some things are not. Our opinions, intentions and actions are up to us. Other people's opinions, our reputation, the weather, the economy and the past are not. Stoics train themselves to spend energy on the first group and to accept the second group calmly. When a person worries about something outside his control, he suffers twice: once in imagination and once in reality.

Interpretations, not events. A Stoic notices that an event is neutral until the mind gives it a meaning. A traffic jam is only a traffic jam. Anger appears when we add the judgment that this should not be happening to me. By slowing down and examining that judgment, we can often change our emotional response before it takes over.

Negative visualization. Stoics practise imagining that they could lose things they value, such as health, a job or a relationship. This is not meant to make life gloomy. It makes the present more precious, reduces fear of loss, and prepares the mind to cope if hardship really arrives. Seneca called this practice premeditation of evils.

Living according to virtue. For the Stoics, the highest good is a good character, expressed through wisdom, courage, justice and self-discipline. Wealth, fame and comfort may be pleasant, but they are not required for a good life, and chasing them can make a person anxious and dependent on others.

Practical habits. Stoics recommend a daily review of the day, asking what went well, what went wrong and what could be done better tomorrow. They also recommend journaling, working with other people instead of against them, and looking at problems from a wider point of view, remembering how small our troubles are in the long span of time.

Why it matters for young people. Young people today face pressure from exams, careers and social media, and anxiety is very common. Stoic ideas can help by separating what a person can change from what he cannot, by encouraging calm and rational reflection, and by reminding readers that a meaningful life is built from character and effort rather than from approval.
""".trimIndent()

    private val isekaiText = """
Background. In the digital era, information is everywhere, yet interest in reading and the ability to understand what is read remain low in Indonesia. Many people spend hours every day on gadgets, but most of that time goes to short videos, chats and social media rather than books, articles or deeper reading. When reading habits weaken, thinking skills also weaken, because long texts train people to follow arguments, compare ideas and remember details.

The problem of information. Not all information circulating on the internet is accurate. Hoaxes, misleading headlines and edited images spread quickly because they are emotional and easy to share. A society that cannot filter information is easy to manipulate, so literacy is not only the ability to read words but also the ability to ask who wrote something, what evidence supports it and whether other sources agree.

Gadgets as a tool, not an enemy. Gadgets themselves are not the cause of the problem. The same device that distracts a student can also open a library of thousands of books. The challenge is to change how gadgets are used, turning scrolling time into learning time, and to give young people tools that make reading more interesting and more interactive.

The idea of ISEKAI. The ISEKAI application stands for Inspiration, Solutions, Education and Actual Creation of Indonesia. It aims to bring together books, essays and learning tools in a single mobile application. Readers can read a text, ask questions about it, request a summary, practise with quizzes and view the main ideas as an infographic. By making reading active rather than passive, the application hopes to make literacy something that young Indonesians enjoy.

Conclusion. A smart generation is not made by banning gadgets but by guiding how they are used. If literacy becomes the starting point of digital habits, then young people can learn to filter information, think critically and create useful ideas for the future of Indonesia.
""".trimIndent()

    val all: List<Book> = listOf(
        Book(
            id = "crime-and-punishment",
            title = "Crime and Punishment",
            author = "Fyodor Mikhailovich Dostoyevsky",
            genre = Genre.FICTION,
            description = "Crime and Punishment[a] is a novel by the Russian author Fyodor Dostoevsky. It was first published in the literary journal The Russian Messenger in twelve monthly installments during 1866. It was later published in a single volume. It is the second of Dostoevsky's full-length novels following his return from ten years of exile in Siberia. Crime and Punishment is considered the first great novel of his mature period of writing[2] and is often cited as one of the greatest works of world literature",
            content = crimeText,
            coverRes = R.drawable.cover_crime,
            underlined = listOf("[a]", "novel", "Fyodor Dostoevsky", "The Russian Messenger", "exile in Siberia", "[2]", "world literature"),
            builtIn = true,
        ),
        Book(
            id = "filosofi-teras",
            title = "Filosofi Teras (Indonesian)",
            author = "",
            genre = Genre.NONFICTION,
            description = "Filosofi Teras is an introductory book on Stoic philosophy specifically designed as a moral guide for young people. It was written to address the high level of anxiety nationally, particularly among young Indonesians. Filosofi Teras was created through collaboration between several parties, including the illustrator, Levina Lesmana, who contributed significantly to the book's cover design, and the author, Henry Manampiring, who was inspired by the book How to be a Stoic by Massimo Pigliucci, a renowned Italian philosopher and Stoic writer. The book is supplemented with data such as a national anxiety survey and interviews with several figures considered experts in psychology.",
            content = filosofiText,
            coverRes = R.drawable.cover_filosofi,
            underlined = listOf("on Stoic philosophy", "moral", "Levina Lesmana", "Henry Manampiring", "How to be a Stoic", "Massimo Pigliucci", "Italian", "Stoic", "psychology"),
            builtIn = true,
        ),
        Book(
            id = "isekai",
            title = "Aplikasi ISEKAI (Inspirasi, Solusi, Edukasi, dan Kreasi Aktual Indonesia): Generasi Cerdas dari Gadget, Dimulai dari Literasi!",
            author = "",
            genre = Genre.NONFICTION,
            description = "This essay discusses the low level of interest in reading and the limited literacy skills among the Indonesian population in the digital era. Excessive use of gadgets has led many people to prefer engaging with social media over reading. Furthermore, not all information circulating on the internet is accurate; therefore, it is essential for the public to possess the ability to filter information and think critically.",
            content = isekaiText,
            coverRes = R.drawable.cover_isekai,
            builtIn = true,
        ),
    )
}
