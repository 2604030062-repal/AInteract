package id.ainteract.app.data

import androidx.annotation.DrawableRes

enum class Genre(val label: String) {
    FICTION("Fiction"),
    NONFICTION("Nonfiction"),
}

data class Book(
    val id: String,
    val title: String,
    val author: String,
    val genre: Genre,
    val description: String,
    val content: String,
    @DrawableRes val coverRes: Int? = null,
    /** Phrases in [description] that are drawn underlined (like links in the design). */
    val underlined: List<String> = emptyList(),
    val builtIn: Boolean = false,
)

data class User(
    val username: String,
    val displayName: String,
)

data class ChatMessage(
    val id: Long,
    val from: String,
    val to: String,
    val body: String,
    val ts: Long,
)

data class Conversation(
    val peer: User,
    val last: ChatMessage?,
    val unread: Int,
)
