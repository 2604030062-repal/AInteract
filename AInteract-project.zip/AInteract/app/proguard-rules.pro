# Nothing special needed: the app uses only framework APIs + Compose.
